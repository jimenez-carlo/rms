<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<style type="text/css">
  .table input {
    width: 150px;
  }
</style>

<div class="container-fluid">
  <div class="row-fluid">
    <div class="block">
      <div class="navbar navbar-inner block-header">
          <div class="pull-left">Registration</div>
      </div>
      <div class="block-content collapse in">
        <form method="post" class="form-horizontal">
          <?php print form_hidden('ltid', $ltid); ?>

          <table class="table">
            <thead>
              <tr>
                <th><p>Branch</p></th>
                <th><p>Date Sold</p></th>
                <th><p>Customer Name</p></th>
                <th><p>Engine #</p></th>
                <th><p>Type of Sales</p></th>
                <th><p>Registration</p></th>
                <th><p>CR #</p></th>
                <th><p>MV File #</p></th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($table as $sales)
              {
                $key = '['.$sales->sid.']';
                print '<tr>';
                print '<td>'.$sales->bcode.' '.$sales->bname.'</td>';
                print '<td>'.$sales->date_sold.'</td>';
                print '<td>'.$sales->first_name.' '.$sales->last_name.'</td>';
                print '<td>'.$sales->engine_no.'</td>';
                print '<td>'.$sales->sales_type.'</td>';
                print '<td>'.form_input('registration'.$key, set_value('registration'.$key, $sales->registration), array('class' => 'numeric')).'</td>';
                print '<td>'.form_input('cr_no'.$key, set_value('cr_no'.$key)).'</td>';
                print '<td>'.form_input('mvf_no'.$key, set_value('mvf_no'.$key)).'</td>';
                print '</tr>';
              }
              ?>
            </tbody>
          </table>

          <div class="form-actions">
            <input type="submit" value="Preview Summary" class="btn btn-success">
          </div>
        </form>
      </div>
    </div>
  </div>
</div>