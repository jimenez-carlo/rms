<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
  <div class="row-fluid">
    <div class="block">
      <div class="navbar navbar-inner block-header">
        <div class="pull-left">CA List</div>
      </div>
      <div class="block-content collapse in">
        <form class="form-horizontal" method="post">
          <fieldset>
            <div class="control-group span5">
              <div class="control-label">CA Date</div>
              <div class="controls">
                <span style="display:inline-block;width:50px">From:</span>
                <?php print form_input('date_from', set_value('date_from', date('Y-m-d')), array('class' => 'datepicker')); ?>
                <br>
                <span style="display:inline-block;width:50px">To:</span>
                <?php print form_input('date_to', set_value('date_to', date('Y-m-d')), array('class' => 'datepicker')); ?>
              </div>
            </div>
            <?php
              $status = array_merge(array('_any' => '- Any -'), $status);
              echo '<div class="control-group span5">';
              echo form_label('Status', 'status', array('class' => 'control-label'));
              echo '<div class="controls">';
              echo form_dropdown('status', $status, set_value('status', $def_stat));
              echo '</div></div>';
            ?>
            <div class="form-actions span4">
              <input type="submit" class="btn btn-success" value="Apply">
            </div>
          </fieldset>
        </form>

        <hr>
        <table class="table">
          <thead>
            <tr>
              <th><p>Reference #</p></th>
              <th><p>Document #</p></th>
              <th><p>Entry Date</p></th>
              <th><p>Debit Memo #</p></th>
              <th><p>Date Deposited</p></th>
              <th style="text-align:right;padding-right:10px;"><p>Amount</p></th>
              <th><p>Region</p></th>
              <th><p>Company</p></th>
              <th><p>Status</p></th>
            </tr>
          </thead>
          <tbody>
            <?php
            foreach ($table as $row)
            {
              print '<tr>';
              print '<td>'.$row->reference.'</td>';
              print '<td>'.$row->voucher_no.'</td>';
              print '<td>'.$row->date.'</td>';
              print '<td>'.$row->dm_no.'</td>';
              print '<td>'.$row->transfer_date.'</td>';
              print '<td style="text-align:right;padding-right:10px;">'.number_format($row->amount,2,'.',',').'</td>';
              print '<td>'.$row->region.'</td>';
              print '<td>'.$row->company.'</td>';
              print '<td>'.$row->status.'</td>';
              print '</tr>';
            }

            if (empty($table))
            {
              print '<tr>
                <td>No result.</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                </tr>';
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>