<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
	<div class="row-fluid">
    <!-- block -->
    <div class="block">
      <div class="navbar navbar-inner block-header">
        <div class="pull-left">Attachment</div>
      </div>
      <div class="block-content collapse in">
      	<form method="post" enctype="multipart/form-data" class="form-horizontal">

	        <!-- Sales Form -->
	        <div class="span5 sales-form">
	          <?php
	          if (isset($sales))
	          {
		          print '<div class="control-group">';
		          print '<div class="control-label">Branch</div>';
		          print '<div class="controls">'.$sales->bcode.' '.$sales->bname.'</div>';
							print '</div>';
							
		          print '<div class="control-group">';
		          print '<div class="control-label">Customer</div>';
		          print '<div class="controls">'.$sales->first_name.' '.$sales->last_name.'</div>';
		          print '</div>';

		          print '<div class="control-group">';
		          print '<div class="control-label">Engine #</div>';
		          print '<div class="controls">'.$sales->engine_no.'</div>';
							print '</div>';

		          print '<div class="control-group">';
		          print '<div class="control-label">Registration</div>';
		          print '<div class="controls">'.$sales->registration.'</div>';
		          print '</div>';

		          print '<div class="control-group">';
		          print '<div class="control-label">CR #</div>';
		          print '<div class="controls">'.form_input('cr_no', $sales->cr_no).'</div>';
		          print '</div>';

		          print '<div class="control-group">';
		          print '<div class="control-label">MV File #</div>';
		          print '<div class="controls">'.form_input('mvf_no', $sales->mvf_no).'</div>';
		          print '</div>';

		          print '<div class="control-group">';
		          print '<div class="control-label">Plate #</div>';
		          print '<div class="controls">'.form_input('plate_no', $sales->plate_no).'</div>';
		          print '</div>';
						}
						else
						{
		          print '<div class="control-group">';
		          print '<div class="control-label">Engine #</div>';
							print '<div class="controls">';
							print form_input('engine_no', set_value('engine_no'));
							print form_submit('search', 'Search', array('class' => 'btn btn-success'));
							print '</div>';
		          print '</div>';
						}
	          ?>
	        </div>

	        <!-- Attachments -->
	        <div class="span7 upload-form">
	          <?php
	          $temp = set_value('temp');
	          if (!empty($temp))
	          {
	            foreach ($temp as $key => $file)
	            {
	              print '<div class="attachment temp" style="position:relative">';
	              print form_hidden('tempkeys[]', $key);

	              $path = './rms_dir/temp/'.$file['file_name'];
	              print '<img src="'.$path.'" style="margin:1em; border:solid">';

	              print '<a href="#" style="background:#BDBDBD; color:black; padding:0.5em; position:absolute; top: 1em">X</a>';
	              print '</div>';
	            }
	          }
	          ?>

	          <!-- Upload Form -->
	          <div class="control-group" style="margin-top: 10px;">
	            <div class="control-label">
	              Upload File
	            </div>
	            <div class="controls">
	              <input type="file" name="scanFiles[]" class="input-file uniform_on" id="scanFiles" multiple>
	              <br>
	              <b>Required file format: jpeg, jpg</b>
	              <br><b>You can only upload upto 1MB</b>
	            </div>
	          </div>
	          <div class="form-actions">
	          	<a class="btn btn-success" onclick="upload()">Upload</a>
	          </div>
	        </div>
        </form>
			</div>
		</div>
	</div>
</div>