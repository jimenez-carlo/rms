<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="row-fluid">
	<center>
		<div class="welcome-title">Welcome to Registration Monitoring System v2</div>
	</center>
</div>