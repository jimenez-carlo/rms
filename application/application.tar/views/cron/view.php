<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
  <div class="row-fluid">
    <div class="block">
      <div class="navbar navbar-inner block-header">
        <div class="pull-left">Run Cron</div>
      </div>
      <div class="block-content collapse in">
        <form class="form-horizontal" method="post" onsubmit="return confirm('Manual cron run cannot be reverted without admin help. Continue?');">
          <fieldset>
            <div class="control-group">
              <div class="control-label">Date</div>
              <div class="controls">
                <?php
                print form_input('date_yesterday', set_value('date_yesterday', date('Y-m-d', strtotime('-1 days'))), array('class' => 'datepicker')) ?>
              </div>
            </div>
          </fieldset>

          <hr>
          <div class="form-actions">
            <input type="submit" name="submit[1]" value="Create RMS data based on data from LTO Transmittal System [rms_create]" class="btn btn-success">
            <hr>
            <input type="submit" name="submit[2]" value="Update rms_expense table for BOBJ Report [rms_expense]" class="btn btn-success">
          </div>
        </form>
      </div>
    </div>
  </div>
</div>