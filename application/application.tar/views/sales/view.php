<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container-fluid form-horizontal">
	<div class="row-fluid">
    <div class="block">
      <div class="navbar navbar-inner block-header">
        <div class="pull-left">Customer Sales # <?php print $sales->sid; ?></div>
      </div>
      <div class="block-content collapse in">

        <!-- Sales Block -->
        <div class=" span6">
          <div class="control-group">
            <div class="control-label">Branch</div>
            <div class="controls text"><?php print $sales->bcode.' '.$sales->bname; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Date Sold</div>
            <div class="controls text"><?php print $sales->date_sold; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Type of Sales</div>
            <div class="controls text"><?php print $sales->sales_type; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Customer Name</div>
            <div class="controls text"><?php print $sales->first_name.' '.$sales->last_name; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Customer Code</div>
            <div class="controls text"><?php print $sales->cust_code; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Engine #</div>
            <div class="controls text"><?php print $sales->engine_no; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Chassis #</div>
            <div class="controls text"><?php print $sales->chassis_no; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">SI #</div>
            <div class="controls text"><?php print $sales->si_no; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">AR #</div>
            <div class="controls text"><?php print $sales->ar_no; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Amount Given</div>
            <div class="controls text"><?php print $sales->amount; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Registration Type</div>
            <div class="controls text"><?php print $sales->registration_type; ?></div>
          </div>
        </div>

        <!-- Status Block -->
        <div class="span6">
          <div class="control-group">
            <div class="control-label">Status</div>
            <div class="controls text"><?php print $sales->status; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Last updated on</div>
            <div class="controls text"><i><?php print $sales->last_update; ?></i></div>
          </div>
          <div class="control-group">
            <div class="control-label">LTO Transmittal</div>
            <div class="controls text"><?php print $sales->transmittal_date; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Pending at LTO</div>
            <div class="controls text"><?php print $sales->pending_date; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Registered on</div>
            <div class="controls text"><?php print $sales->registration_date; ?></div>
          </div>
        </div>

        <hr class="span12">

        <!-- Expense Block -->
        <div class=" span4">
          <div class="control-group">
            <div class="control-label">Insurance</div>
            <div class="controls text"><?php print $sales->insurance; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Registration</div>
            <div class="controls text"><?php print $sales->registration; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">CR #</div>
            <div class="controls text"><?php print $sales->cr_no; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">MV File #</div>
            <div class="controls text"><?php print $sales->mvf_no; ?></div>
          </div>
          <div class="control-group">
            <div class="control-label">Plate #</div>
            <div class="controls text"><?php print $sales->plate_no; ?></div>
          </div>
        </div>

        <!-- Attachment Block -->
        <div class="span8">
          <?php
          if (!empty($sales->files))
          {
            foreach ($sales->files as $key => $file)
            {
              print '<div class="attachment" style="position:relative">';
              print form_hidden('filekeys[]', $key);

  					  $exp = explode('.', $file);
  					  $ext = array_pop($exp);
  					  $path = './../../rms_dir/scan_docs/'.$sales->sid.'_'.$sales->engine->engine_no.'/'.$file;

              print '<img src="'.$path.'" style="margin:1em; border:solid">';

              print '<a href="#" style="background:#BDBDBD; color:black; padding:0.5em; position:absolute; top: 1em">X</a>';
              print '</div>';
            }
          }
          else
          {
          	print '<div class="control-group"><div class="controls text">No attachments.</div></div>';
          }
          ?>
        </div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
$(function(){
  $(document).ready(function(){
    $('.controls').each(function(){
      if (!$(this).text()) $(this).text('-');
    });
  });
})
</script>