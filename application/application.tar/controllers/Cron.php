<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends MY_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->helper('url');
		$this->load->helper('directory');
		$this->load->model('Login_model', 'login');
  }

	public function index()
	{
		$this->access(1);
		$this->header_data('title', 'Cron');
		$this->header_data('nav', 'cron');
		$this->header_data('dir', './');

		// on generate
		$submit = $this->input->post('submit');
		if (!empty($submit))
		{
			$key = current(array_keys($submit));
			$this->manual($key);
		}

		$this->template('cron/view');
	}

	public function manual($key)
	{
		$date_yesterday = $this->input->post('date_yesterday');
		if (substr($date_yesterday, 0, 10) <= date('Y-m-d', strtotime('-1 days')))
		{
			$log = $this->db->query("select * from tbl_cron_log
				where ckey = ".$key."
				and date = '".$date_yesterday."'")->row();

			if (empty($log))
			{
				switch($key)
				{
					case 1: $this->rms_create(); break;
					case 2: $this->rms_expense(); break;
				}
				$_SESSION['messages'][] = 'Cron executed successfully.';
			}
			else {
				$_SESSION['warning'][] = 'Cron was executed before on '.date('F n, Y H:i:s', strtotime($log->start)).'.';
			}
		}
		else {
			$_SESSION['warning'][] = 'Cannot execute future cron date.';
		}
	}

	public function rms_create()
	{
		$start = date("Y-d-m H:i:s");
		$rows = 0;

		$global = $this->load->database('global', TRUE);
		$dev_rms = $this->load->database('dev_rms', TRUE);

		$date_yesterday = $this->input->post('date_yesterday');
		$date_yesterday = (empty($date_yesterday))
			? date('Y-m-d', strtotime('-1 days')) : $date_yesterday;

		$result = $dev_rms->query("select c.*, r.*, date_created, regn_status
			from customer_tbl c
			inner join rrt_reg_tbl r on branch_code = branch
			inner join transmittal_tbl on transmittal_code = transmittal_no
			inner join regn_status on engine_nr = engine_no
			where left(date_created, 10) = '".$date_yesterday."'")->result_object();
		foreach ($result as $row)
		{
			$sales = $this->db->query("select nid from rms_expense
				where engine_num = '".$row->engine_no."'
				and custcode = '".$row->customer_id."'")->row();

			if (empty($sales))
			{
				// branch dtls
				switch ($row->rrt_class)
				{
					case 'NCR': $region = 1; $r_code = 'NCR'; break;
					case 'REGION 1': $region = 2; $r_code = 'R1'; break;
					case 'REGION 2': $region = 3; $r_code = 'R2'; break;
					case 'REGION 3': $region = 4; $r_code = 'R3'; break;
					case 'REGION 4': $region = 5; $r_code = 'R4'; break;
					case 'REGION 4 B': $region = 6; $r_code = 'R4b'; break;
					case 'REGION 5': $region = 7; $r_code = 'R5'; break;
					case 'REGION 6': $region = 8; $r_code = 'R6'; break;
					case 'REGION 7': $region = 9; $r_code = 'R7'; break;
					case 'REGION 8': $region = 10; $r_code = 'R8'; break;
					default: $region = 0;
				}
				$company = (substr($row->branch, 0, 1) == 6) ? 2 : substr($row->branch, 0, 1);
				$branch = $global->query("select * from tbl_branches where b_code = '".$row->branch."'")->row();

				// lto_transmittal
				$code = 'LT-'.$r_code.'-'
					.substr($row->branch, 0, 1).'0'
					.substr($row->date_created, 2, 2)
					.substr($row->date_created, 5, 2)
					.substr($row->date_created, 8, 2);
				$transmittal = $this->db->query("select * from tbl_lto_transmittal
					where code = '".$code."'")->row();
				if (empty($transmittal))
				{
					$transmittal = new Stdclass();
					$transmittal->date = $row->date_created;
					$transmittal->code = $code;
					$transmittal->region = $region;
					$transmittal->company = $company;
					$this->db->insert('tbl_lto_transmittal', $transmittal);
					$transmittal->ltid = $this->db->insert_id();	
				}

				// engine
				$engine = $this->db->query("select * from tbl_engine
					where engine_no = '".$row->engine_no."'")->row();
				if (empty($engine))
				{
					$engine = new Stdclass();
					$engine->engine_no = $row->engine_no;
					$engine->chassis_no = $row->chassis_no;
					$this->db->insert('tbl_engine', $engine);
					$engine->eid = $this->db->insert_id();
				}

				// customer
				$customer = $this->db->query("select * from tbl_customer
					where cust_code = '".$row->customer_id."'")->row();
				if (empty($customer))
				{
					$customer = new Stdclass();
					$customer->first_name = $row->first_name;
					$customer->last_name = $row->last_name;
					$customer->cust_code = $row->customer_id;
					$customer->cust_type = (empty($row->first_name) || empty($row->last_name)) ? 1 : 0;
					$this->db->insert('tbl_customer', $customer);
					$customer->cid = $this->db->insert_id();
				}

				// sales
				$sales = $this->db->query("select * from tbl_sales
					where engine = ".$engine->eid."
					and customer = ".$customer->cid)->row();
				if (empty($sales))
				{
					$sales = new Stdclass();
					$sales->engine = $engine->eid;
					$sales->customer = $customer->cid;
					$sales->branch = (!empty($branch)) ? $branch->bid : 0;
					$sales->bcode = $row->branch_code;
					$sales->bname = $row->branch_name;
					$sales->region = $region;
					$sales->company = $company;
					$sales->date_sold = $row->date_sold;
					$sales->si_no = $row->sales_invoice;
					$sales->ar_no = $row->ar_no;
					$sales->amount = $row->amount_given;
					$sales->sales_type = ($row->sale_type == 465) ? 0 : 1;
					$sales->registration_type = $row->regn_status;
					$sales->transmittal_date = $row->date_created;
					$sales->lto_transmittal = $transmittal->ltid;
					$this->db->insert('tbl_sales', $sales);
					$sales->sid = $this->db->insert_id();
				}

				// expense
				$expense = new Stdclass();
				$expense->nid = $sales->sid;
				$expense->custcode = $customer->cust_code;
				$expense->engine_num = $engine->engine_no;
				$this->db->insert('rms_expense', $expense);

				$rows++;
			}
		}
		$end = date("Y-d-m H:i:s");

		$log = new Stdclass();
		$log->ckey = 1;
		$log->date = $date_yesterday;
		$log->start = $start;
		$log->end = $end;
		$log->rows = $rows;
		$this->db->insert('tbl_cron_log', $log);

		$this->login->saveLog('Run Cron: Create RMS data based on data from LTO Transmittal System [rms_create] Duration: '.$start.' - '.$end);

		$submit = $this->input->post('submit');
		if (empty($submit)) redirect('cron');
	}

	public function rms_expense()
	{
		$start = date("Y-d-m H:i:s");
		$rows = 0;

		$dev_ces2 = $this->load->database('dev_ces2', TRUE);

		$date_yesterday = $this->input->post('date_yesterday');
		$date_yesterday = (empty($date_yesterday))
			? date('Y-m-d', strtotime('-1 days')) : $date_yesterday;

		// update lto pending sales
		$tip = $this->db->query('select sid,pending_date
			from tbl_sales s
			where left(pending_date,10) = "'.$date_yesterday.'"')->result_object();
		foreach ($tip as $t) {
			$obj_t = new Stdclass();
			$obj_t->tip_conf = 0;
			$obj_t->tip_conf_d = $t->pending_date;
			$dev_ces2->update('rms_expense', $obj_t, array('nid' => $sale->sid));
			$rows++;
		}

		// update registered sales
		$sales = $this->db->query('select sid,registration,registration_date
			from tbl_sales	 s
			inner join tbl_customer c on customer=cid
			inner join tbl_engine e on engine=eid
			where left(registration_date,10) = "'.$date_yesterday.'"')->result_object();
		foreach ($sales as $sale) {
			$obj_e = new Stdclass();
			$obj_e->regn_exp = $sale->registration;
			$obj_e->regn_exp_d = $sale->registration_date;
			$dev_ces2->update('rms_expense', $obj_e, array('nid' => $sale->sid));
			$rows++;
		}
		$end = date("Y-d-m H:i:s");

		$log = new Stdclass();
		$log->ckey = 2;
		$log->date = $date_yesterday;
		$log->start = $start;
		$log->end = $end;
		$log->rows = $rows;
		$this->db->insert('tbl_cron_log', $log);

		$this->login->saveLog('Run Cron: Update rms_expense table for BOBJ Report [rms_expense] Duration: '.$start.' - '.$end);

		$submit = $this->input->post('submit');
		if (empty($submit)) redirect('cron');
	}
}