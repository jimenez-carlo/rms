<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fund_transfer extends MY_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->helper('url');
    $this->load->model('Fund_transfer_model', 'fund_transfer');
  }

	public function index()
	{
		$this->access(1);
		$this->header_data('title', 'Process Transfer');
		$this->header_data('nav', 'fund_transfer');
		$this->header_data('dir', './');

		$data['table'] = $this->fund_transfer->get_for_process();
		$this->template('fund_transfer/for_process', $data);
	}

	public function process_transfer($vid)
	{
		$data['voucher'] = $this->fund_transfer->get_voucher($vid);
		$view = $this->load->view('fund_transfer/process_transfer', $data, TRUE);
		echo json_encode($view);
	}

	public function save_process($vid)
	{
		$err_msg = array();

		$this->form_validation->set_rules('dm_no', 'Debit Memo #', 'required');
		$this->form_validation->set_rules('process_date', 'Date Processed', 'required');

    if ($this->form_validation->run() == FALSE) {
    	$err_msg[] = validation_errors();
    }
    
		if (!empty($err_msg)) echo json_encode(array("status" => FALSE, "message" => $err_msg));
		else $this->true_save_process($vid);
	}

	public function true_save_process($vid)
	{
		$offline = $this->input->post('offline');

  	$voucher = new Stdclass();
		$voucher->dm_no = $this->input->post('dm_no');
		$voucher->process_date = $this->input->post('process_date');
		$voucher->offline = (isset($offline));
		$voucher->status = 1;
		$this->db->update('tbl_voucher', $voucher, array('vid' => $vid));
		
		$_SESSION['messages'][] = 'Debit Memo # '.$voucher->dm_no.' saved successfully.';
		echo json_encode(array("status" => TRUE));
	}

  /**
   * Treasury to Transfer Fund
   */
	public function for_deposit()
	{
		$this->access(1);
		$this->header_data('title', 'Fund Transfer');
		$this->header_data('nav', 'fund_transfer');
		$this->header_data('dir', './../');

		$data['table'] = $this->fund_transfer->get_for_transfer();
		$this->template('fund_transfer/for_transfer', $data);
	}

	public function transfer_fund($vid)
	{
		$data['voucher'] = $this->fund_transfer->get_voucher($vid);
		$view = $this->load->view('fund_transfer/transfer_fund', $data, TRUE);
		echo json_encode($view);
	}

	public function save_transfer($vid)
	{
		$err_msg = array();
		$this->form_validation->set_rules('transfer_date', 'Date Deposited', 'required');

    if ($this->form_validation->run() == FALSE) {
    	$err_msg[] = validation_errors();
    }
    
		if (!empty($err_msg)) echo json_encode(array("status" => FALSE, "message" => $err_msg));
		else $this->true_save_transfer($vid);
	}

	public function true_save_transfer($vid)
	{
		$offline = $this->input->post('offline');

  	$voucher = new Stdclass();
		$voucher->vid = $vid;
		$voucher->transfer_date = $this->input->post('transfer_date');
		$voucher->offline = (isset($offline));
		$voucher->status = 2;
		$voucher = $this->fund_transfer->save_transfer($voucher);
		
		$_SESSION['messages'][] = 'Deposited fund of Debit Memo # '.$voucher->dm_no.' for '.$voucher->region.' '.$voucher->company.'.';
		echo json_encode(array("status" => TRUE));
	}
}
