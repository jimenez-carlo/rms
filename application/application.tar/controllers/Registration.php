<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Registration_model', 'registration');
		$this->load->model('Sales_model', 'sales');
		$this->load->model('File_model', 'file');
	}

	public function index()
	{
		$this->access(1);
		$this->header_data('title', 'Registration');
		$this->header_data('nav', 'registration');
		$this->header_data('dir', './');

		$data['region'] = $_SESSION['region'];
		$data['ltid'] = $this->input->post('ltid');
		$data['registration'] = $this->input->post('registration');
		$data['cr_no'] = $this->input->post('cr_no');
		$data['mvf_no'] = $this->input->post('mvf_no');
		$data['expense'] = $this->input->post('expense');
		$data['submit_all'] = $this->input->post('submit_all');
		$data['back'] = $this->input->post('back');

		if (!empty($data['submit_all'])) {
			$this->registration->register_sales($data);
			redirect('registration');
		}
		 
		if (empty($data['ltid'])) {
			$data['table'] = $this->registration->load_list($data);
			$this->template('registration/list', $data);
		}
		else {
	 		if (is_array($data['ltid'])) {
	 			$data['ltid'] = current(array_keys($data['ltid']));
	 		}

			if (!empty($data['registration'])) {
				foreach ($data['registration'] as $sid => $registration)
				{
					if (empty($data['registration'][$sid])
						|| empty($data['cr_no'][$sid])
						|| empty($data['mvf_no'][$sid])) {
							unset($data['registration'][$sid]);
							unset($data['cr_no'][$sid]);
							unset($data['mvf_no'][$sid]);
						}
				}

				if (empty($data['registration'])) {
					$_SESSION['warning'][] = 'No records to update.';
				}
			}

			if (empty($data['registration']) || !empty($data['back'])) {
				$data['table'] = $this->registration->list_sales($data);
				$this->template('registration/sales', $data);
			}
			else {
				$data['transmittal'] = $this->registration->load_sales($data);
				$this->template('registration/summary', $data);
			}
		}
	}
}
