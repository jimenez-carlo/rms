<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rerfo extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Rerfo_model', 'rerfo');
	}

	public function index()
	{
		$this->access(1);
		$this->header_data('title', 'Rerfo');
		$this->header_data('nav', 'rerfo');
		$this->header_data('dir', './');

		$param = new Stdclass();
		$param->branches = $_SESSION['branches'];
		$param->date_from = $this->input->post('date_from');
		$param->date_to = $this->input->post('date_to');
		$param->branch = $this->input->post('branch');
		$param->print = $this->input->post('print');

		$data['table'] = $this->rerfo->list_rerfo($param);
		$data['branches'] = $this->rerfo->dd_branches($param->branches);
		$this->template('rerfo/list', $data);
	}

	public function view()
	{
		$this->access(1);
		$this->header_data('title', 'Rerfo');
		$this->header_data('nav', 'rerfo');
		$this->header_data('dir', './../');

		$view = $this->input->post('view');
		if (empty($view)) redirect('rerfo');
		$rid = current(array_keys($view));

		$data["rerfo"] = $this->rerfo->load($rid);
		$this->template('rerfo/view', $data);
	}

	public function sprint() 
	{
		$print = $this->input->post('print');
		if (empty($print)) redirect('rerfo');
		$rid = current(array_keys($print));

		$data['rerfo'] = $this->rerfo->print_rerfo($rid);
		$this->load->view('rerfo/print', $data);
	}

	public function request($rid)
	{
		$request = $this->input->post('request');
		if (empty($request)) redirect('rerfo');
		$rid = current(array_keys($request));

    if ($this->rerfo->request_reprint($rid)) {
    	$_SESSION['messages'][] = 'Request for reprint sent.';
    }
    else {
    	$_SESSION['warning'][] = 'Request for reprint already sent.';
    }
    redirect('rerfo');
	}
}
