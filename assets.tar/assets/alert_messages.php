<?php
$changes_saved = '
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<i class="icon-ok"></i>
  <b>Success!</b> Changes has been saved.
</div>';

$old_pw_incorrect = '
<div class="alert alert-danger">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<i class="icon-exclamation-sign"></i>
  <b>Error!</b> Entered old password is incorrect. No changes were made.
</div>';
?>